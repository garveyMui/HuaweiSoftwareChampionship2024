//
// Created by Administrator on 2024/3/7.
//
#include "Goods.h"
#include "Robot.h"
#include "get_shortest_path.h"
#ifndef LOVEAPPLE_CHOSE_A_GOODS_H
#define LOVEAPPLE_CHOSE_A_GOODS_H


Position choose_a_goods(Robot& robot);


#endif //LOVEAPPLE_CHOSE_A_GOODS_H
