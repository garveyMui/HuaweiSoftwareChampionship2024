//
// Created by 梅佳伟 on 2024/3/8.
//
#include "Boat.h"
#include <vector>
#ifndef APPLEFANS_SELECT_BOAT_FROM_QUEUE_H
#define APPLEFANS_SELECT_BOAT_FROM_QUEUE_H

using namespace std;
int select_boat_from_queue (vector<Boat> boats);


#endif //APPLEFANS_SELECT_BOAT_FROM_QUEUE_H
