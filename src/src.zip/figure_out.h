//
// Created by 梅佳伟 on 2024/3/12.
//

#ifndef MAIN_FIGURE_OUT_H
#define MAIN_FIGURE_OUT_H
#include <vector>

using namespace std;
class Figure_out{
public:
    void do_figure_out();
    vector<vector<int>> connected_robots();
};


#endif //MAIN_FIGURE_OUT_H
