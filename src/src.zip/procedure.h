//
// Created by 梅佳伟 on 2024/3/8.
//

#ifndef APPLEFANS_PROCEDURE_H
#define APPLEFANS_PROCEDURE_H


class Procedure {
public:
    void do_procedure();
};


#endif //APPLEFANS_PROCEDURE_H
