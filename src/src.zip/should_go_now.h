//
// Created by 梅佳伟 on 2024/3/8.
//
#include "Boat.h"

#ifndef APPLEFANS_SHOULD_SHIP_NOW_H
#define APPLEFANS_SHOULD_SHIP_NOW_H


bool should_go_now (Boat boat);


#endif //APPLEFANS_SHOULD_SHIP_NOW_H
