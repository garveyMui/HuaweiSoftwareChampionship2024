//
// Created by Administrator on 2024/3/18.
//

#ifndef APPLE_SHOULD_REVOLVE_DESTINATIONS_H
#define APPLE_SHOULD_REVOLVE_DESTINATIONS_H


class should_revolve_destinations {

};


#endif //APPLE_SHOULD_REVOLVE_DESTINATIONS_H
