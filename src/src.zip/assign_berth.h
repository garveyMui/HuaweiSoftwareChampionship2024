//
// Created by Administrator on 2024/3/14.
//

#ifndef MAIN_ASSIGN_BERTH_H
#define MAIN_ASSIGN_BERTH_H
#include "Robot.h"

void assign_berth(Robot & robot);


#endif //MAIN_ASSIGN_BERTH_H
