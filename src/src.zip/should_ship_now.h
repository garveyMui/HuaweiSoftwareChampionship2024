//
// Created by 梅佳伟 on 2024/3/12.
//
#include "Boat.h"
#ifndef MAIN_SHOULD_SHIP_NOW_H
#define MAIN_SHOULD_SHIP_NOW_H


bool should_ship_now(Boat& boat);


#endif //MAIN_SHOULD_SHIP_NOW_H
