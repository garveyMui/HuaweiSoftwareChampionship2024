//#include "../data_structures/Berth.h"
//#include "../data_structures/Robot.h"
//#ifndef LOVEAPPLE_UPDATE_H
//#define LOVEAPPLE_UPDATE_H
//
///*
// *
// */
//void update(Robot robot); //更新机器人状态
//void update(Boat boat);  //更新船只状态
//
//
//#endif //LOVEAPPLE_UPDATE_H
