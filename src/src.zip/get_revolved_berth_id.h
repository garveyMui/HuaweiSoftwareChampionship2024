//
// Created by Administrator on 2024/3/18.
//

#ifndef APPLE_GET_REVOLVED_BERTH_ID_H
#define APPLE_GET_REVOLVED_BERTH_ID_H


class get_revolved_berth_id {

};


#endif //APPLE_GET_REVOLVED_BERTH_ID_H
