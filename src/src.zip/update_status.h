//
// Created by Administrator on 2024/3/9.
//
#include "Robot.h"

#ifndef LOVEAPPLE_UPDATE_STATUS_H
#define LOVEAPPLE_UPDATE_STATUS_H


void update_robot_status (int goods,int x,int y,int sts,Robot& robot);
void update_boat_status (int sts, int pos,Boat& boat,int boat_id);
void update_berth_status();

#endif //LOVEAPPLE_UPDATE_STATUS_H
