//
// Created by Administrator on 2024/3/7.
//
#include "Berth.h"
#include "Robot.h"
#include "get_shortest_path.h"
#ifndef LOVEAPPLE_CHOSE_A_BERTH_H
#define LOVEAPPLE_CHOSE_A_BERTH_H

/*
 * 从
 */
int choose_a_berth(Robot& robot);
int choose_a_berth(Boat boat);  //重载函数名，行为是为船只选择港口



#endif //LOVEAPPLE_CHOSE_A_BERTH_H
