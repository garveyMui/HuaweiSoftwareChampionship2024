//
// Created by 梅佳伟 on 2024/3/8.
//
#include "Robot.h"

#ifndef APPLEFANS_GET_CAR_PRIORITY_H
#define APPLEFANS_GET_CAR_PRIORITY_H


double get_car_priority (Robot robot);


#endif //APPLEFANS_GET_CAR_PRIORITY_H
