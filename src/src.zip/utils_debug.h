//
// Created by 梅佳伟 on 2024/3/12.
//

#ifndef MAIN_UTILS_DEBUG_H
#define MAIN_UTILS_DEBUG_H
#include "Position.h"
#include "queue"
using namespace std;
std::string vectorPairToString(std::queue<Position> pairs);


#endif //MAIN_UTILS_DEBUG_H
